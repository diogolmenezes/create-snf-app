# Doc

This doc folder contains swagger-ui

Write you api documentation at doc/swagger.yml or running npm run doc:edit.

Than run npm run doc:update to update your swagger.json doc file.

# SNF Updating the swagger-ui

To update the swagger-ui download the version at https://github.com/swagger-api/swagger-ui/tree/master/dist
than change index.html to point to swagger.json